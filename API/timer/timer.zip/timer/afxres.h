#pragma once
#include <windows.h>
#define IDC_STATIC -1
